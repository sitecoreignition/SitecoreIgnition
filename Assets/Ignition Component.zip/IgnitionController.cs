﻿using System.Web.Mvc;
using $rootnamespace$.Bases;
using $rootnamespace$.MVC;

namespace $rootnamespace$
{
    public class $safeitemname$ : BaseController
    {
        public $safeitemname$(IRepository repository) : base(repository)
        {
        }
    }
}
