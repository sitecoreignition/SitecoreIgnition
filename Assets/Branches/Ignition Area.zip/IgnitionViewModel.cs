﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $rootnamespace$.Bases;
using $rootnamespace$.MVC;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractViewModel
    {
        public $safeitemname$(IRepository repository) : base(repository)
        {
        }

        public override string ViewPath { get; set; }
    }
}
