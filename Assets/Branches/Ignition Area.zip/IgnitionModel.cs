﻿using Glass.Mapper.Sc.Configuration.Attributes;
using Ignition.Core.Models;

namespace $rootnamespace$
{
    [SitecoreType(TemplateId = "")]
    public interface $safeitemname$ : IModelBase
    {

    }
}
