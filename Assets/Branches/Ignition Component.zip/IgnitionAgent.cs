﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $rootnamespace$.Bases;
using $rootnamespace$.MVC;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractViewAgent<AbstractViewModel>
    {
        public $safeitemname$(IRepository repository, SitecoreData sitecoreData) : base(repository, sitecoreData)
        {
        }

        public override void PopulateModel()
        {
            
        }
    }
}
